package com.infinityjump.ide.window.properties;

import javafx.scene.layout.Pane;

public abstract class PropertyPane extends Pane {
	public abstract void update();
}
