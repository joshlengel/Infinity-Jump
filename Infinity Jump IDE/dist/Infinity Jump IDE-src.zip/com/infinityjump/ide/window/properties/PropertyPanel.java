package com.infinityjump.ide.window.properties;

import javafx.scene.layout.Pane;

public abstract class PropertyPanel extends Pane {
	public abstract void update();
}
