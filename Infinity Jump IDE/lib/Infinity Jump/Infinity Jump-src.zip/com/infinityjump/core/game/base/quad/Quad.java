package com.infinityjump.core.game.base.quad;

import java.math.BigDecimal;

public class Quad {

	public BigDecimal x, y, width, height;
}
