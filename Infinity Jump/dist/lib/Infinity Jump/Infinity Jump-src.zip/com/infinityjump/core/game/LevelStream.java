package com.infinityjump.core.game;

public interface LevelStream {
	
	boolean hasNext();
	
	Level next();
}
